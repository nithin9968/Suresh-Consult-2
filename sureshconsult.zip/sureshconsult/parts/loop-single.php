<?php
/**
 * Template part for displaying a single post
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
						


	<!-- <div class="featured_image_single">
		<?php //the_post_thumbnail('full'); ?>
	</div> -->	
	<div class="single_title">
		<h2><?php the_title(); ?></h2>
	</div>
	<div class="description">
		<?php the_content(); ?>
	</div>
	<div class="source_url">
		<?php 

		$link = get_field('external_link');

		if( $link ): ?>
			
			<a class="button" href="<?php echo $link; ?>">Source Url</a>

		<?php endif; ?>
		<?php if( have_rows('tooltips') ): ?>
		<div class="tooltip_templates">
			<?php while( have_rows('tooltips') ): the_row(); 
				$tooltip_id = get_sub_field('tooltip_id');
				$tooltip_image = get_sub_field('tooltip_image');
				$tooltip_title = get_sub_field('tooltip_title');
				$tooltip_content = get_sub_field('tooltip_content');
			?>
		    <span id="<?php echo $tooltip_id; ?>">
		    	<div class="tooltip_content" style="display: inline-block;">
		    		<h5><?php echo $tooltip_title; ?></h5>
		    		<img src="<?php echo $tooltip_image['url']; ?>" alt="<?php echo $tooltip_image['alt'] ?>" />
		    		<?php echo $tooltip_content; ?>
		    	</div>
		         
		    </span>
		    <?php endwhile; ?>
		</div>
		<?php endif; ?>
	</div>
													
</article> <!-- end article -->