<?php
/**
 * Template part for displaying posts
 *
 * Used for single, index, archive, search.
 */
?>

				
	<div class="large-4 small-4 medium-3 cell single_archive_cell">
		<?php $backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );?>
		<a href="<?php the_permalink()?>">
		<div class="featured_image_box" >
			<?php the_post_thumbnail('full'); ?>
			<div class="single_title">
				<h4><?php the_title(); ?></h4>
			</div>
			
		</div>
	</a>
	</div>
	
				    						

