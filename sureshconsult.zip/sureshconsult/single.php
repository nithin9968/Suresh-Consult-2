<?php 
/**
 * The template for displaying all single posts and attachments
 */

get_header(); ?>
			
<div class="grid-container full" id="single_post_row">
	<div class="large-10 small-11 medium-11 cell text-center theme_title">
		<a href="<?php echo home_url(); ?>" style="color: #0a0a0a;"><h3>Projects</h3></a>
		<!-- <p>Suresh Consult India</p> -->
	</div>
	<div class="grid-x align-center">
		<div class="large-10 small-11 medium1-11 cell single_post_wrapper text-jusity">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		    	<?php get_template_part( 'parts/loop', 'single' ); ?>
		    	
		    <?php endwhile; else : ?>
		
		   		<?php get_template_part( 'parts/content', 'missing' ); ?>

		    <?php endif; ?>
		</div>
	</div>
</div>

<?php get_footer(); ?>