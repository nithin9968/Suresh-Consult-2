<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 */

get_header(); ?>
<!-- <div class="grid-container full" id="topbar">
	<div class="grid-x align-center">
		
	</div>
</div> -->			
<div class="grid-container full" id="project_archive_row">
	<div class="grid-x align-center">
		<div class="large-10 small-11 medium-11 cell text-center theme_title">
			<a href="<?php echo home_url(); ?>" style="color: #0a0a0a;"><h3>Projects</h3></a>
			<!-- <p>Suresh Consult India</p> -->
		</div>
		<div class="large-10 small-11 medium-11 cell archive_wrapper">

		<div class="frame">
			<div class="quote">
				<p style="padding: 2em 0;">I must fight with all my strength so that the little positive things that my allows me to do might be pointed toward helping the revolution. The only real reason for living.</p>

				
			</div>
		</div>

			<div class="grid-x grid-margin-x">

			    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			 
					<!-- To see additional archive styles, visit the /parts directory -->
					<?php get_template_part( 'parts/loop', 'archive' ); ?>
				    
				<?php endwhile; ?>	

					<?php joints_page_navi(); ?>
					
				<?php else : ?>
											
					<?php get_template_part( 'parts/content', 'missing' ); ?>
						
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>