<?php
/**
 * The template for displaying the footer. 
 *
 * Comtains closing divs for header.php.
 *
 * For more info: https://developer.wordpress.org/themes/basics/template-files/#template-partials
 */			
 ?>
					
				<footer class="footer" role="contentinfo">
					
					<div class="inner-footer grid-x grid-margin-x grid-padding-x">
						
						<div class="small-12 medium-12 large-12 cell">
							<nav role="navigation">
	    						<?php joints_footer_links(); ?>
	    					</nav>
	    				</div>
						
						<div class="small-12 medium-12 large-12 cell">
							<p class="source-org copyright">&copy; <?php echo date('Y'); ?> Suresh Consult India<?php //bloginfo('name'); ?>.</p>
						</div>
					
					</div> <!-- end #inner-footer -->
				
				</footer> <!-- end .footer -->
			
			</div>  <!-- end .off-canvas-content -->
					
		</div> <!-- end .off-canvas-wrapper -->
		
		<?php wp_footer(); ?>
		<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/assets/scripts/js/tooltipster.bundle.min.js"></script>
		<script>
		  WebFont.load({
		    google: {
		      families: ['Delius+Unicase:700', 'Roboto:400,500']
		    }
		  });
		</script>
		<script>
			jQuery('.tooltip').tooltipster({
			   animation: 'fade',
			      delay: 200,
			      theme: 'tooltipster-light',
			       trigger:'hover'
			      // trigger: 'custom',
			      //     triggerOpen: {
			      //         click: true,
			      //         interactive:true
			      //     },
			      //     triggerClose: {
			      //         click: true,
			      //         scroll: true
			      //     }
			});
		</script>

		
	</body>
	
</html> <!-- end page -->